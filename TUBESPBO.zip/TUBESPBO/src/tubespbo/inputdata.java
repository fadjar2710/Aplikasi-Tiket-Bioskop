/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubespbo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import net.proteanit.sql.DbUtils;
/**
 *
 * @author user
 */
public class inputdata {
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    
    private String sql;
    public String Nama;
    public String Film;
    public String JenisTiket;
    public String JamTayang;
    public String HargaTiket;
    public String Jumlahbeli;
    public String Total;
    
    public void simpan()throws SQLException{
        conn = koneksi.getKoneksi();
        sql = "INSERT INTO tiketbioskop(Nama,Film,JenisTiket,JamTayang,HargaTiket,JumlahBeli,Total)VALUES(?,?,?,?,?,?,?)";
        pst = conn.prepareStatement(sql);
        pst.setString(1, Nama);
        pst.setString(2, Film);
        pst.setString(3, JenisTiket);
        pst.setString(4, JamTayang);
        pst.setString(5, HargaTiket);
        pst.setString(6, Jumlahbeli);
        pst.setString(7, Total);
        pst.execute();
        pst.close();
    }
    
    public ResultSet UpdateJTable()throws SQLException{
        conn = koneksi.getKoneksi();
        sql = "select*from tiketbioskop";
        pst = conn.prepareStatement(sql);
        rs = pst.executeQuery();
        return rs;
    }
}
